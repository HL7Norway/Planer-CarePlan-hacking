# Planer Care Plan v 1 - Planer CarePlan Hacking v0.3.0

* [**Table of Contents**](toc.md)
* **Planer Care Plan v 1**

## Planer Care Plan v 1

## CarePlan med vurderingssoner for observasjoner (grønn/gul/rød)

For å støtte planoppfølging med tydelig alvorlighetsnivå brukes en tre-nivå sonemodell:

* **Grønn sone (`green`)**: Forventet nivå, normal oppfølging.
* **Gul sone (`yellow`)**: Avvik som krever økt oppfølging eller revurdering.
* **Rød sone (`red`)**: Kritisk avvik som krever rask intervensjon.

I denne guiden ligger **planens sonedefinisjoner** i `CarePlan.addresses` (via `PlanerHackingZoneCondition`), mens observasjoner kan uttrykke **målt status** separat ved behov.

Se også [v2](planer-CarePlan-v2.md), en alternativ modell der tiltaket for hver sone beskrives i `CarePlan.activity` på en egen sone-CarePlan i stedet for i `Condition.note`.

### Sonebeskrivelse for pasient i CarePlan

`PlanerHackingCarePlan` bruker ikke extension for soner. I stedet beskrives sonene som `Condition`-ressurser som refereres fra `CarePlan.addresses`. Dette uttrykker **planens definerte soner** (terskler og tiltak), ikke selve observasjonsmålingen:

* `CarePlan.addresses` peker til `PlanerHackingZoneCondition`.
* Hver `PlanerHackingZoneCondition` inneholder: 
* `clinicalStatus` (obligatorisk)
* `severity.coding[zoneSystem].system` = sonekodeverk (obligatorisk)
* `severity.coding[zoneSystem].code` = sonenivå `green | yellow | red` (obligatorisk)
* `code.text` = terskel/område (f.eks. "Peak flow 50-80%")
* `note.text` = anbefalt tiltak for sonen
 
* `CarePlan.description`/`CarePlan.note` kan brukes for overordnet planinformasjon og personlige mål.

Denne modellen gjør sone-definisjoner eksplisitte og gjenbrukbare i standard FHIR-struktur, uten egne CarePlan-extensions.

### PlantUML-modell for sonebeskrivelse

Modell der CarePlan adresserer sone-Condition med nivå, terskel og tiltak

### Eksempel (pasientplan med soner)

Et komplett eksempel er definert i FSH-instansene:

* [`CarePlan-Oddfrid-Zones`](CarePlan-CarePlan-Oddfrid-Zones.md)
* [`ZoneCondition-Green-Oddfrid`](Condition-ZoneCondition-Green-Oddfrid.md)
* [`ZoneCondition-Yellow-Oddfrid`](Condition-ZoneCondition-Yellow-Oddfrid.md)
* [`ZoneCondition-Red-Oddfrid`](Condition-ZoneCondition-Red-Oddfrid.md)

Eksempelet viser samme prinsipp som i Pasientens planer API: hver sone modelleres med terskel i `PlanerHackingZoneCondition.code.text`, tiltak i `PlanerHackingZoneCondition.note.text` og nivå i `PlanerHackingZoneCondition.severity.coding[zoneSystem].code`, referert fra `CarePlan.addresses`.

